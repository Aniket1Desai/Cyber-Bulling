import streamlit as st
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
# Load the model
model = pickle.load(open('svm_model.pkl', 'rb'))
# Load the TF-IDF vectorizer
with open('tfidf_vectorizer.pkl', 'rb') as file:
    tfidf_vectorizer = pickle.load(file)

# Set the background image and text color
background_image = """
<style>
[data-testid="stAppViewContainer"] > .main {
    background-image: url("https://media.istockphoto.com/id/1330904062/photo/person-with-a-hoody-typing-at-a-computer-in-the-dark-suspicious-online-behavior.jpg?s=1024x1024&w=is&k=20&c=WAZsFlg119oWrRDA0PV-xs611k8wGmvBryQazScaq4A=");
    background-size: 100vw 100vh;
    background-position: center;  
    background-repeat: no-repeat;
    color: #FFFFFF; /* Set text color to blue */
}
</style>
"""

st.markdown(background_image, unsafe_allow_html=True)

# Streamlit app
def main():
    st.title('Cyberbullying Prediction')
    # new_title = '<p style="font-family:sans-serif; color:Green; font-size: 42px;">Cyberbullying Prediction App</p>'
    # st.markdown(new_title, unsafe_allow_html=True)

    # Text input for user input
    user_input = st.text_area('Enter a tweet:')
    
    # if st.button('Predict'):
    #     # Reshape input data to a 2D array
    #     user_input_reshaped = tfidf_vectorizer.transform([user_input])
        

    #     # Make prediction using the loaded SVM model
    #     prediction = model.predict(user_input_reshaped)
    #     st.write(f'Predicted sentiment: {prediction[0]}')


    if st.button('Predict'):
        # Transform user input using TF-IDF vectorizer
        user_input_tfidf = tfidf_vectorizer.transform([user_input])

        # Make prediction using the loaded SVM model
        prediction = model.predict(user_input_tfidf)

        # Map encoded sentiment to sentiment name
        sentiment_mapping = {
            1: "Religion",
            2: "Age",
            3: "Ethnicity",
            4: "Gender",
            5: "Other Cyberbullying",
            6: "Not Cyberbullying"
        }

        # Get the sentiment name corresponding to the predicted encoded value
        predicted_sentiment = sentiment_mapping[prediction[0]]
        
        st.write(f'Predicted sentiment: {predicted_sentiment}')


if __name__ == '__main__':
    main()
